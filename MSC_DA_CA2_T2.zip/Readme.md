<h1 align='center'>Welcome to MSC_DA_CA2_T2👋</h1>

> This is a project undergone as part of Study performed for the CCT College Dublin as an element of a M.s, Data Analytics programme.

This project was made with Python💻

## Version
1.0.32

## Install
```sh
Required libraries:
!pip install pytz
!pip install tweepy
!pip install statsmodels
!pip install plotly
!pip install wordcloud
!pip install textblob
!pip install nltk
```

## Usage
```sh
Input the correct Twitter API Credentials into the config.json
```

## Author

👤 **SBA20368**

## Show your support

Give a ⭐️ if this project helped you!

Readme created with ❤️ using [NESS](https://github.com/GreenVortex/NESS)
